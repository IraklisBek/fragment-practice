const mongoose = require('mongoose');

// const postSchema = mongoose.Schema({
//     title: { type: String, required: true },
//     content: { type: String, required: true },
//     imagePath: { type: String, required: true },
//     creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
// });

const postSchema = mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    kind: { type: String, required: true },
    location: { type: String, required: true },
    main_photo: { type: String, required: true },
    description: { type: String },
    title: { type: String, required: true },
    photos: { type: [String]},
    videos: { type: [String]},
    music: { type: [String]},
});

module.exports = mongoose.model('Post', postSchema);//collection will automatically be posts